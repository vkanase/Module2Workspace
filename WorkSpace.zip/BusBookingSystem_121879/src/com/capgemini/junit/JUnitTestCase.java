package com.capgemini.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDAOImpl;
import com.capgemini.exception.BookingException;

public class JUnitTestCase {

    BusDAOImpl busDAO = null ;
    BusBean bus = null ;
    BookingBean bookBus = null ;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception
	{
		busDAO = new BusDAOImpl() ;
		bookBus = new BookingBean() ;
		
		//bookBus.setBookingId(1020);
		bookBus.setCustId("A123456");
		bookBus.setBusId(2);
		bookBus.setNoOfSeat(1);
		
	}

	@After
	public void tearDown() throws Exception 
	{
		busDAO = null ;
	}

	@Test
	public void testRetrieveBusDetails() 
	{
		try
		{
			assertNotNull(busDAO.retrieveBusDetails());
		}
		catch(BookingException e)
		{
			
		}
	}

	@Test
	public void testBookTicket() 
	{
		assertEquals(1020, busDAO.bookTicket(bookBus));
	}

}

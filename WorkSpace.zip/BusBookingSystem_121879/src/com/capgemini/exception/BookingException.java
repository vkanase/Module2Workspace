package com.capgemini.exception;

public class BookingException extends  RuntimeException 
{

	public BookingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BookingException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BookingException(String arg0) {
		super(arg0);
		System.out.println(arg0);
		// TODO Auto-generated constructor stub
	}

	public BookingException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}

class BusIdException extends Exception
{
	public BusIdException() 
	{
		System.out.println("BusId does Not exist");
	}
}

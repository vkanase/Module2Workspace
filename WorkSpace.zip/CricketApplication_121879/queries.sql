drop table players ;

create table players 
(
	id number,
	name varchar2(30),
	dob date,
	country varchar2(30),
	batStyle varchar2(30),
	centuries number(5),
	matchesPlayed number(5),
	totalScore number(10),
	primary key(id)
);

select * from players;

create sequence seqPlyId start with 100;

delete players where id = 102;
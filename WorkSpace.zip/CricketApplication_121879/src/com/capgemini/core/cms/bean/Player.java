package com.capgemini.core.cms.bean;

import java.sql.Date;

public class Player 
{
	private int id ;
	private String name ;
	private Date dob ;
	private String country ;
	private String battiingStyle ;
	private int centuries ;
	private int matchesPlayed;
	private int score;
	
	public Player()
	{
		super();
	}

	public Player(int id, String name, Date dob, String country,
			String battiingStyle, int centuries, int matchesPlayed, int score) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.country = country;
		this.battiingStyle = battiingStyle;
		this.centuries = centuries;
		this.matchesPlayed = matchesPlayed;
		this.score = score;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBattiingStyle() {
		return battiingStyle;
	}

	public void setBattiingStyle(String battiingStyle) {
		this.battiingStyle = battiingStyle;
	}

	public int getCenturies() {
		return centuries;
	}

	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}

	public int getMatchesPlayed() {
		return matchesPlayed;
	}

	public void setMatchesPlayed(int matchesPlayed) {
		this.matchesPlayed = matchesPlayed;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", country=" + country + ", battiingStyle=" + battiingStyle
				+ ", centuries=" + centuries + ", matchesPlayed="
				+ matchesPlayed + ", score=" + score + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Player other = (Player) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
	
}

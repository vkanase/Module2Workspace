package com.capgemini.core.cms.service;

import java.util.List;

import com.capgemini.core.cms.bean.Player;
import com.capgemini.core.cms.dao.IPlayerDAO;
import com.capgemini.core.cms.dao.PlayerDAOImpl;
import com.capgemini.core.cms.exception.PlayerException;

public class PlayerServiceImpl implements IPlayerService {

	private IPlayerDAO playerDAO;
	
	public  PlayerServiceImpl()
	{
		playerDAO = new PlayerDAOImpl();
	}
	@Override
	public int addPlayer(Player player) throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.addPlayer(player);
	}

	@Override
	public void updatePlayer(Player player) throws PlayerException {
		System.out.println("Currently in service");
		playerDAO.updatePlayer(player);

	}

	@Override
	public Player getPlayer(int id) throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.getPlayer(id);
	}

	@Override
	public List<Player> getPlayers() throws PlayerException {
		// TODO Auto-generated method stub
		return playerDAO.getPlayers();
	}

}

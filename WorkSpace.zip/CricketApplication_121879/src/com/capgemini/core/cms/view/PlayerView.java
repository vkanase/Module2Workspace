package com.capgemini.core.cms.view;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.cms.bean.Player;
import com.capgemini.core.cms.exception.PlayerException;
import com.capgemini.core.cms.service.IPlayerService;
import com.capgemini.core.cms.service.PlayerServiceImpl;



public class PlayerView 
{
	private IPlayerService playerService;
	
	public PlayerView()
	{
		playerService = new PlayerServiceImpl();
	}
	
	public static void main(String[] args) 
	{
		PlayerView playerView = new PlayerView();
		while(true)
		{
			playerView.showMenu();
		}
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("1. Add Player ");
		System.out.println("2. Get Player");
		System.out.println("3. Update Player");
		System.out.println("4. View All Player");
		System.out.println("5. Exit application");
		
		System.out.println("Enter Your choice ");
		int choice = scanner.nextInt();
		
		switch(choice)
		{
			case 1 : addPlayer();
				break;
			
			case 2 : getPlayer();
				break;
			
			case 3 : updatePlayer();
				break;
			
			case 4 :getPlayers();
				break;
				
			case 5 :System.out.println("Thanks");
					System.exit(0);
				break;
			
			default : System.out.println("Enter Valid Input...");
				break;
		}
	}

	private void getPlayers()
	{
		try
		{
			List<Player> players = playerService.getPlayers();
			
			Iterator<Player> it = players.iterator();
			
			System.out.println("ID \t\t Name \t\t DOB \t\t Country \t\t BattingStyle \t\t Centuries \t\t MatchesPlayed \t\t TotalScore");
			while(it.hasNext())
			{
				Player player = it.next();
				
				System.out.println(player.getId() +"\t\t"+ player.getName() +"\t\t"+ player.getDob() +"\t\t"+ player.getCountry()
						+"\t\t"+player.getBattiingStyle()+"\t\t"+player.getCenturies()+"\t\t"+player.getMatchesPlayed() +"\t\t"+player.getScore());;
			}
			
			
		}
		catch(PlayerException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	private void updatePlayer()

	{

	Scanner scanner = new Scanner(System.in);

	System.out.println("Updating Player Information");

	System.out.println("\n Player ID: ");

	int id = scanner.nextInt();

	try {

	//attempting to get player assuming id passed is valid

	Player player = playerService.getPlayer(id);

	//Since Player obj is retrieved,updated it and send to updatePlayer

	System.out.println("Name: "+player.getName() );

	System.out.println("Do you want to update Name (y/n)?");

	char reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player Name

	{

	System.out.println("Enter new name: ");

	String name= scanner.next();

	player.setName(name);

	}

	System.out.println("Date Of Birth " + player.getDob());
	System.out.println("Do you want to update Date Of Birth ");
    reply = scanner.next().toLowerCase().charAt(0);
	
	if(reply == 'y')
	{
		System.out.println("Enter Date Of Birth to Update ");
		String dob = scanner.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt = sdf.parse(dob);
		java.sql.Date date = new Date(dt.getTime());
		player.setDob(date);
	}
	
	
	System.out.println("Country: "+player.getCountry() );

	System.out.println("Do you want to update Country (y/n)?");

	reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player Country

	{

	System.out.println("Enter new Country: ");

	String country= scanner.next();

	player.setCountry(country);

	}

	System.out.println("Batting Style: "+player.getBattiingStyle() );

	System.out.println("Do you want to update Batting Style (y/n)?");

	reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player Batting Style

	{

	System.out.println("Enter new Batting Style: ");

	String batsty= scanner.next();

	player.setBattiingStyle(batsty);

	}

	System.out.println("No of Centuries: "+player.getCenturies() );

	System.out.println("Do you want to update No of Centuries (y/n)?");

	reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player No of centuries

	{

	System.out.println("Enter new No of centuries: ");

	int centuries= scanner.nextInt();

	player.setCenturies(centuries);

	}

	System.out.println("No of Matches Played: "+player.getMatchesPlayed() );

	System.out.println("Do you want to update No of Matches Played (y/n)?");

	reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player No of Matches Played

	{

	System.out.println("Enter new No of Matches Played: ");

	int matches= scanner.nextInt();

	player.setMatchesPlayed(matches);

	}

	System.out.println("Total Runs Scored: "+player.getScore() );

	System.out.println("Do you want to update No of Total Runs Scored (y/n)?");

	reply = scanner.next().toLowerCase().charAt(0);

	if(reply == 'y')//Updating player Total Runs Scored

	{

	System.out.println("Enter new Total Runs Scored: ");

	int runs= scanner.nextInt();

	player.setScore(runs);

	}

	playerService.updatePlayer(player);

	}

	catch (PlayerException e)

	{

	e.printStackTrace();

	}

	catch (Exception e)

	{

	e.printStackTrace();

	}

	}
	private void getPlayer() 
{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Retrieving Player Information");
		System.out.println("Enter Player ID ");
	    int id = scanner.nextInt();
	    
	    try
	    {
	    	Player player = playerService.getPlayer(id);
	    	
	    	System.out.println("Player Information");
	    	
	    	System.out.println("ID :" + player.getId());
	    	System.out.println("Name " + player.getName());
	    	System.out.println("Date of Birth " + player.getDob());
	    	System.out.println("Country : " + player.getCountry());
	    	System.out.println("Batting Style :" + player.getBattiingStyle());
	    	System.out.println("Centuries :" + player.getCenturies());
	    	System.out.println("Matches Played :" + player.getMatchesPlayed());
	    	System.out.println("Total Score : "+player.getScore());
	    }
	    catch(PlayerException e)
	    {
	    	e.printStackTrace();
	    }
		catch(Exception e)
	    {
			e.printStackTrace();
	    }
	}

	private void addPlayer() 
{
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Adding Player Information");
		
		System.out.println("Enter Player Name ");
		String name = scanner.next();
		
		System.out.println("Enter Date Of Birth");
		String dob = scanner.next();
		
		System.out.println("Enter Country");
		String country = scanner.next();
		
		System.out.println("Enter Batting Style");
		String batStyle = scanner.next();
		
		System.out.println("Enter Number of centuries ");
		int centuries = scanner.nextInt();
		
		System.out.println("Enter Matches Played ");
        int matchPlayed = scanner.nextInt();
        
        System.out.println("Enter Total Score ");
        int totalScore = scanner.nextInt();
        
        Player player = new Player();
		
        player.setName(name);
		
		Date date = Date.valueOf(dob);
		player.setDob(date);

		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt;
		try 
		{
			dt = sdf.parse(dob);
			java.sql.Date date = new Date(dt.getTime());
			player.setDob(date);
		} 
		catch (ParseException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		player.setCountry(country);
		player.setBattiingStyle(batStyle);
		player.setCenturies(centuries);
		player.setMatchesPlayed(matchPlayed);
		player.setScore(totalScore);
		
		playerService.addPlayer(player);
	}
}

package com.capgemini.core.cms.dao;

import java.util.List;

import com.capgemini.core.cms.bean.Player;
import com.capgemini.core.cms.exception.PlayerException;

public interface IPlayerDAO 
{
	public int addPlayer(Player player) throws PlayerException ;
	public void updatePlayer(Player player ) throws PlayerException ;
	public Player getPlayer(int id) throws PlayerException ;
	public List<Player> getPlayers() throws PlayerException ;
}

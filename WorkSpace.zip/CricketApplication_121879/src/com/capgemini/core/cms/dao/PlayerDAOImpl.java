package com.capgemini.core.cms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.cms.bean.Player;
import com.capgemini.core.cms.exception.PlayerException;
import com.capgemini.core.cms.util.DBUtil;


public class PlayerDAOImpl implements IPlayerDAO {

	@Override
	public int addPlayer(Player player) throws PlayerException {
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection())
		{
			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select seqPlyId.nextval from dual");
			
			if(res.next()==false)
			{
				throw new PlayerException("Something went wrong while generating id");
			}
			
			int id = res.getInt(1);
			String name = player.getName();
			Date dob = player.getDob();
			String country = player.getCountry();
			String batStyle = player.getBattiingStyle();
			int centuries = player.getCenturies();
			int matchesPlayed = player.getMatchesPlayed();
			int totalScore = player.getScore();
			
			PreparedStatement pstmt = con.prepareStatement
					("insert into players values (?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			pstmt.setDate(3, dob);
			pstmt.setString(4, country);
			pstmt.setString(5, batStyle);
			pstmt.setInt(6,centuries);
			pstmt.setInt(7, matchesPlayed);
			pstmt.setInt(8, totalScore);
			
			pstmt.execute();
			
			generatedId = id;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		return generatedId;
	}

	@Override
	public void updatePlayer(Player player) throws PlayerException {
		try(Connection con = DBUtil.getConnection())
		{
			System.out.println("Vinayak pagal");
			int id = player.getId();
			String name = player.getName();
			Date date = player.getDob();
			String country = player.getCountry();
			String batStyle = player.getBattiingStyle();
			int centuries = player.getCenturies();
			int matchPlayed = player.getMatchesPlayed();
			int score = player.getScore();
			
			PreparedStatement pstm = con.prepareStatement("update players set name = ? ,dob = ? , country = ? , batstyle = ?,centuries = ? , matchesplayed = ? , totalscore = ? where id = ? ");
			pstm.setString(1, name);
			pstm.setDate(2 ,date);
			pstm.setString(3, country);
			pstm.setString(4, batStyle);
			pstm.setInt(5, centuries);
			pstm.setInt(6, matchPlayed);
			pstm.setInt(7, score);
			pstm.setInt(8, id);
			
			pstm.executeUpdate();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}

	}

	@Override
	public Player getPlayer(int id) throws PlayerException {
		Player player = null;
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from players where id = ?");
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			if(res.next() == false )
			{
				throw new PlayerException("No Player  found with Id "+id);
			}
			
			player = new Player();
			player.setId(id);
			player.setName(res.getString("name"));
			player.setDob(res.getDate("dob"));
			player.setCountry(res.getString("country"));
			player.setBattiingStyle(res.getString("batstyle"));
			player.setCenturies(res.getInt("centuries"));
			player.setMatchesPlayed(res.getInt("matchesplayed"));
			player.setScore(res.getInt("totalscore"));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		return player;
	}

	@Override
	public List<Player> getPlayers() throws PlayerException {
		List<Player> players = new ArrayList<Player>();
		try(Connection con = DBUtil.getConnection())
		{
			Statement stmt = con.createStatement();
			ResultSet res =stmt.executeQuery("select * from players");
			while(res.next())
			{
				Player player = new Player();
				
				
				player.setId(res.getInt("id"));
				player.setName(res.getString("name"));
				player.setDob(res.getDate("dob"));
				player.setCountry(res.getString("country"));
				player.setBattiingStyle(res.getString("centuries"));
				player.setMatchesPlayed(res.getInt("matchesplayed"));
				player.setScore(res.getInt("totalscore"));
				
				players.add(player);
 			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new PlayerException(e.getMessage());
		}
		return players;
	}

}

package com.capgemini.core.cms;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.capgemini.core.cms.bean.Player;
import com.capgemini.core.cms.service.PlayerServiceImpl;

public class Test
{
	public static void main(String[] args) throws ParseException
	{
		PlayerServiceImpl playerServiceImpl = new PlayerServiceImpl();
		
		/*Player player = new Player();
		player.setName("Sachin");

		String d = "1973-04-24" ;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt = sdf.parse(d);
		java.sql.Date date = new Date(dt.getTime());
		player.setDob(date);
		
		player.setCountry("India");
		player.setBattiingStyle("Right Hand Batsman");
		player.setCenturies(60);
		player.setMatchesPlayed(551);
		player.setScore(99999);
		
		playerServiceImpl.addPlayer(player);*/
		
		/*Player player = playerServiceImpl.getPlayer(120);
		System.out.println(player);*/
		
		//update
		Player player = new Player();
		player.setId(120);
		player.setName("Sachin Tendulkar");

		String d = "1973-04-24" ;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date dt = sdf.parse(d);
		java.sql.Date date = new Date(dt.getTime());
		player.setDob(date);
		
		player.setCountry("India");
		player.setBattiingStyle("Right Hand Batsman");
		player.setCenturies(60);
		player.setMatchesPlayed(551);
		player.setScore(99999);
		
		playerServiceImpl.updatePlayer(player);
		
		/*List<Player> players = playerServiceImpl.getPlayers();
		for(Player p : players)
		{
			System.out.println(p);
		}*/
		
		
		
		
	}
}

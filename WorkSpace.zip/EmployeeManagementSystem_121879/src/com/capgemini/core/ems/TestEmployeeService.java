package com.capgemini.core.ems;

import java.util.List;

import oracle.net.aso.e;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class TestEmployeeService 
{
	public static void main(String[] args) 
	{
		EmployeeServiceImpl employeeService = new EmployeeServiceImpl() ;
		
		// Testing add employee Method
		
		/*Employee emp = new Employee();
		emp.setName("Rob Stark");
		emp.setDepartment("Winter Fell");
		emp.setDesignation("Dead");
		emp.setSalary(25000);
		
		employeeService.addEmployee(emp);*/
		
		//End of Add Employee
		
	
		//Getting a single employee detail
		/*Employee emp = employeeService.getEmployee(1002);
		System.out.println(emp);*/
		
		//Updating Employee Details
		/*Employee emp = new Employee();
		emp.setId(1002);
		emp.setName("John Snow");
		emp.setDepartment("Winter Fell");
		emp.setDesignation("King in North");
		emp.setSalary(50000);
		
		employeeService.updateEmployee(emp);*/
		
		//removing employee
		
		Employee employee =employeeService.removeEmployee(1004);
		System.out.println("Employee Removed ");
		System.out.println(employee);
		
		//Getting all employee
		List<Employee> emps = employeeService.getEmployees();
		for(Employee e : emps)
		{
			System.out.println(e);
		}
		
	}
}

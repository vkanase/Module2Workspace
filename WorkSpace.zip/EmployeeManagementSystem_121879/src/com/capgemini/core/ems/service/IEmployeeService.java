package com.capgemini.core.ems.service;

import java.util.List;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exception.EmployeeException;

public interface IEmployeeService 
{
	public int addEmployee(Employee employee) throws EmployeeException ;
	public Employee getEmployee(int id) throws EmployeeException ;
	public void updateEmployee(Employee employee) throws EmployeeException ;
	public Employee removeEmployee(int id) throws EmployeeException ;
	public List<Employee> getEmployees() throws EmployeeException ;
}

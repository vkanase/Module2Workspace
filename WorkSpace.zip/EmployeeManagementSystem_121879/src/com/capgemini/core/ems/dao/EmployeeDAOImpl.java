package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exception.EmployeeException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO
{
	static Logger myLogger ;
	
	public EmployeeDAOImpl() 
	{
		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(EmployeeDAOImpl.class.getName());
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		
		int generatedId = -1;
		try (Connection con = DBUtil.getConnection()) 
		{	
			Statement stm = con.createStatement();
			ResultSet resultSet = stm.executeQuery("select empIdSeq.nextval from dual");
			
			if(resultSet.next() == false )
				throw new EmployeeException("Something went wrong whil generating EmployeeId");
			
			int id = resultSet.getInt(1);
			String name = employee.getName();
			float salary = employee.getSalary();
			String dept = employee.getDepartment();
			String designation = employee.getDesignation();
			
			PreparedStatement pstmStatement = con.prepareStatement
					("insert into employee values (?,?,?,?,?)");
			pstmStatement.setInt(1, id);
			pstmStatement.setString(2, name);
			pstmStatement.setString(3, dept);
			pstmStatement.setString(4, designation);
			pstmStatement.setFloat(5, salary);
			
			pstmStatement.execute();
			generatedId = id ;
			
			myLogger.info("Employee Added Successfully ");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());
		}
		return generatedId ;

	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		Employee employee = null;
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement("select * from employee where id = ?");
			pstm.setInt(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next() == false )
			{
				throw new EmployeeException("No employee  found with Id "+id);
			}
			employee = new Employee();
			employee.setId(id);
			employee.setName(res.getString("name"));
			employee.setDepartment(res.getString("department"));
			employee.setDesignation(res.getString("designation"));
			employee.setSalary(res.getFloat("salary"));
			myLogger.info("Employee shown ");
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {
		
		try(Connection con = DBUtil.getConnection())
		{
			int id = employee.getId();
			String name = employee.getName();
			String depart = employee.getDepartment();
			String design = employee.getDesignation();
			float sal = employee.getSalary();
			
			PreparedStatement psup = con.prepareStatement
					("update employee set name = ? , department = ? , designation = ? , salary = ? where id = ?");
			psup.setString(1, name);
			psup.setString(2, depart);
			psup.setString(3, design);
			psup.setFloat(4, sal);
			psup.setInt(5, id);
			
			psup.execute();
			myLogger.info("Employee updated Successfully ");
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}

	}

	@Override
	public Employee removeEmployee(int id) throws EmployeeException {
		
		Employee employee = null;
		
		try(Connection con = DBUtil.getConnection())
		{
			employee = getEmployee(id);
			if( employee == null )
			{
				throw new EmployeeException("Employee Id " +id+ " doest not exist");
			}
			PreparedStatement pstm = con.prepareStatement("delete from employee where id = ?");
			pstm.setInt(1, id);
			pstm.execute();
			myLogger.info("Employee removed Successfully ");
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employee;
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeException {

		List<Employee> employees = new ArrayList<Employee>();
		try(Connection con = DBUtil.getConnection())
		{
			Statement stmt = con.createStatement();
			ResultSet res =stmt.executeQuery("select * from employee");
			while(res.next())
			{
				Employee employee = new Employee();
				
				employee.setId(res.getInt("id"));
				employee.setName(res.getString("name"));
				employee.setDepartment(res.getString("department"));
				employee.setDesignation(res.getString("designation"));
				employee.setSalary(res.getFloat("salary"));
				
				employees.add(employee);
				myLogger.info("Displayed All Employees  ");
 			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			myLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return employees;
	}

}

package com.capgemini.core.ems.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import oracle.net.aso.e;
import oracle.net.aso.s;

import com.capgemini.core.ems.bean.Employee;
import com.capgemini.core.ems.exception.EmployeeException;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import com.capgemini.core.ems.service.IEmployeeService;

public class EmployeeView {

	//Loose Coupling......
	private IEmployeeService employeeService ;
	
	public EmployeeView()
	{
		employeeService = new EmployeeServiceImpl();
	}
	public static void main(String[] args)
	{
		EmployeeView employeeView = new EmployeeView();
		while(true)
		{
			employeeView.showMenu();
		}
	}
	
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("1. Add Employee ");
		System.out.println("2. Get Employee");
		System.out.println("3. Update Employee");
		System.out.println("4. Remove Employee");
		System.out.println("5. View All Employee");
		System.out.println("6. Exit application");
		
		System.out.println("Enter Your choice ");
		int choice = scanner.nextInt();
		
		switch(choice)
		{
			case 1 : addEmployee();
				break;
			
			case 2 : getEmployee();
				break;
			
			case 3 : updateEmployee();
				break;
				
			case 4 : removeEmployee();
				break;
			
			case 5 :getEmployees();
				break;
				
			case 6 :System.out.println("Thanks");
					System.exit(0);
				break;
			
			default : System.out.println("Enter Valid Input...");
				break;
		}
	}
	
	private void getEmployees() 
	{
		try
		{
			List<Employee> employees = employeeService.getEmployees();
			
			Iterator<Employee> it = employees.iterator();
			System.out.println("ID \t\tName \t\tDepartment \t\tDesignation \t\tSalary");
			while(it.hasNext())
			{
				Employee employee = it.next();
				System.out.println(employee.getId() + "\t\t"  + employee.getName() + "\t\t"
						+ employee.getDepartment() + "\t\t" + employee.getDesignation() + "\t\t"
						+ employee.getSalary());
			}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	private void removeEmployee() {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Removin employee Details ");
		
		System.out.println("\nEnter Employee Id ");

		int id = scanner.nextInt();
		
		try
		{
			Employee employee = employeeService.removeEmployee(id);
			
			System.out.println("Employee "+id +" removed");
			
			System.out.println("Employee Id " + employee.getId());
			System.out.println("Employee Name " + employee.getName());
			System.out.println("Employee Department " + employee.getDepartment());
			System.out.println("Employee Designation " + employee.getDesignation());
			System.out.println("Employee Salary "+ employee.getSalary());
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	private void updateEmployee() 
	{	
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(" Updating Employee Details ");
		System.out.println("\n Employee id ");
		int id = scanner.nextInt();
		
		try
		{
			//attempting to get employee assumin id passd is valid
			Employee employee = employeeService.getEmployee(id);
			
			//Since Employee objs is retrived update it and send to update
			
			//Name
			System.out.println("Name " + employee.getName());
			System.out.println("Do you want to update name ");
			char reply = scanner.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				System.out.println("Enter Name to Update ");
				String name = scanner.next();
				employee.setName(name);
			}
			
			//Department
			System.out.println("Department " + employee.getDepartment());
			System.out.println("Do you want to update Department ");
			reply = scanner.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				System.out.println("Enter Department to Update ");
				String dept = scanner.next();
				employee.setDepartment(dept);
			}
			
			//Designation
			System.out.println("Designation " + employee.getDesignation());
			System.out.println("Do you want to update Desigantion ");
		    reply = scanner.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				System.out.println("Enter Designation to Update ");
				String design = scanner.next();
				employee.setDesignation(design);
			}
			
			//salary
			System.out.println("Salary " + employee.getSalary());
			System.out.println("Do you want to update Salary ");
			reply = scanner.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				System.out.println("Enter Salary to Update ");
				float salary = scanner.nextFloat();
				employee.setSalary(salary);
			}
			
			//updating employee now
			
			employeeService.updateEmployee(employee);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	private void getEmployee() 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Retriving Employee Details");
		System.out.println("Enter Employee Id ");
		int id = scanner.nextInt();
		try
		{
			Employee employee = employeeService.getEmployee(id);
			System.out.println("\n**Employee Information**");
			
			System.out.println("Employee Id " + employee.getId());
			System.out.println("Employee Name " + employee.getName());
			System.out.println("Employee Department " + employee.getDepartment());
			System.out.println("Employee Designation " + employee.getDesignation());
			System.out.println("Employee Salary "+ employee.getSalary());
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	private void addEmployee() 
	{
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(" Enter Employee Details ");
		
		System.out.println(" Enter Employee Name ");
		String name = scanner.next();
		
		System.out.println(" Enter Employee Department ");
		String dept = scanner.next();
		
		System.out.println(" Enter Employee Designation ");
		String design = scanner.next();
		
		System.out.println(" Enter Employee Salary ");
		float salary = scanner.nextFloat();
		
		Employee employee = new Employee();
		employee.setName(name);
		employee.setDepartment(dept);
		employee.setDesignation(design);
		employee.setSalary(salary);
		
		try
		{
			int id = employeeService.addEmployee(employee);
			System.out.println("Employee Added Successfully with id " + id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

}

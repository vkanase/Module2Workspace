drop table employee;


create table employee(
	id number,
	name varchar2(30),
	department varchar2(30),
	designation varchar2(30),
	salary number(10,2),
	primary key(id)
);

select * from employee;

create sequence empIdSeq start with 1000;
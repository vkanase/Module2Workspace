package com.capgemini.core.bub.bean;

import java.sql.Date;

public class Customer 
{
	private int customerId ;
	private String name ;
	private int accid ;
	private String branchName ;
	private int age ;
	private String occupation ;
	private String loanType ;
	private double loanAmount ;
	private Date startDate ;
	private Date endDate ;
	
	public Customer() 
	{
		super();
	}

	public Customer(int customerId, String name, int accid, String branchName,
			int age, String occupation, String loanType, double loanAmount,
			Date startDate, Date endDate) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.accid = accid;
		this.branchName = branchName;
		this.age = age;
		this.occupation = occupation;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name
				+ ", accid=" + accid + ", branchName=" + branchName + ", age="
				+ age + ", occupation=" + occupation + ", loanType=" + loanType
				+ ", loanAmount=" + loanAmount + ", startDate=" + startDate
				+ ", endDate=" + endDate + "]";
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerId != other.customerId)
			return false;
		return true;
	}
	 
	
}

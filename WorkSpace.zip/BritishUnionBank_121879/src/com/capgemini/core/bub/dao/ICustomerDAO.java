package com.capgemini.core.bub.dao;

import com.capgemini.core.bub.bean.Customer;
import com.capgemini.core.bub.exception.CustomerException;

public interface ICustomerDAO 
{
	public int addCustomer( Customer customer ) throws CustomerException ;
	public Customer getCustomer( int id ) throws CustomerException ;
	public Customer removeCustomer( int id ) throws CustomerException ;
	public double calculateTotal( Customer customer ) throws CustomerException ;
	
}

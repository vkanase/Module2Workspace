package com.capgemini.core.bub.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.core.bub.bean.Customer;
import com.capgemini.core.bub.exception.CustomerException;
import com.capgemini.core.bub.util.DBUtil;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public int addCustomer(Customer customer) throws CustomerException 
	{
		int generatedId = -1 ;
		try( Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement() ;
			ResultSet resultSet = stm.executeQuery("select seqCustId.nextval from dual ");
			
			if(resultSet.next() == false)
				throw new CustomerException( "Something went wrong while generating id " );
			
			int id = resultSet.getInt(1) ;
			String name = customer.getName() ;
			int accountid = customer.getAccid() ;
			String branchName = customer.getBranchName() ;
			int age = customer.getAge() ;
			String occup = customer.getOccupation() ;
			String loanType = customer.getLoanType() ;
			double loanAmt = customer.getLoanAmount() ;
			Date startDate = customer.getStartDate() ;
			Date endDate = customer.getEndDate() ;
			
			PreparedStatement pstm = con.prepareStatement("insert into customerBank values (?,?,?,?,?,?,?,?,?,?)");
			pstm.setInt(1,id);
			pstm.setString(2, name );
			pstm.setInt(3, accountid);
			pstm.setString(4,branchName);
			pstm.setInt(5, age);
			pstm.setString(6, occup);
			pstm.setString(7, loanType);
			pstm.setDouble(8, loanAmt);
			pstm.setDate(9, startDate);
			pstm.setDate(10, endDate);
			
			pstm.execute();
			
			generatedId = id ;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage()) ;
		}
		return generatedId;
	}

	@Override
	public Customer getCustomer(int id) throws CustomerException 
	{
		Customer customer = null ;
		try(Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm = con.prepareStatement(" select * from customerbank where customerid = ? ") ;
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery() ;
			if( res.next() == false )
			{
				throw new CustomerException(" No Customer Found with given id " + id) ;
			}
			
			customer = new Customer() ;
			customer.setCustomerId(id);
			customer.setName(res.getString("name")) ;
			customer.setAccid(res.getInt("accountid")) ;
			customer.setBranchName(res.getString("branchName")) ;
			customer.setAge(res.getInt("age")) ;
			customer.setOccupation( res.getString("occupation")) ;
			customer.setLoanType(res.getString("loantype")) ;
			customer.setLoanAmount(res.getDouble("loanamount")) ;
			customer.setStartDate(res.getDate("startDate")) ;
		    customer.setEndDate(res.getDate("endDate")) ;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		return customer;
	}

	@Override
	public Customer removeCustomer(int id) throws CustomerException 
	{
		Customer customer = null ;
		try( Connection con = DBUtil.getConnection() )
		{
			customer = getCustomer( id ) ;
			if(customer == null )
				throw new CustomerException("Customer not found with id " + id ) ;
			
			PreparedStatement pstm = con.prepareStatement("delete from customerbank where customerId = ? ") ;
			pstm.setInt( 1, id );
			
			pstm.execute() ;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new CustomerException( e.getMessage() ) ;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new CustomerException( e.getMessage() ) ;
		}
		return customer;
	}

	@Override
	public double calculateTotal(Customer customer) throws CustomerException 
	{
	
		return 0;
	}

}

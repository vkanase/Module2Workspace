package com.capgemini.core.bub.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil 
{
	public static Connection getConnection() throws SQLException 
	{
		final String PROPFILE = "MyApplication.properties" ;
		
		Properties dbProperties ;
		dbProperties = loadProperties(PROPFILE) ;
		
		OracleDataSource ods = new OracleDataSource() ;
		
		ods.setUser(dbProperties.getProperty("username"));
		ods.setPassword(dbProperties.getProperty("password"));
		ods.setDriverType(dbProperties.getProperty("driver"));
		ods.setNetworkProtocol(dbProperties.getProperty("networkprotocol"));
		ods.setURL(dbProperties.getProperty("url"));
		
		/*ods.setUser("Labg103trg24");
		ods.setPassword("labg103oracle");
		ods.setDriverType("thin");
		ods.setNetworkProtocol("tcp");
		ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");*/
		return ods.getConnection();
	}
	
	private static Properties loadProperties(String fileName)
	{
		InputStream propsFile = null ;
		
		Properties propertyFile = new Properties() ;
		try
		{
			propsFile = new FileInputStream(fileName);
			propertyFile.load(propsFile);
			propsFile.close();
		}
		catch( Exception e)
		{
			System.out.println("Input Output Exception");
			e.printStackTrace();
			System.exit(1);
			
		}
		return propertyFile ;
	}
}

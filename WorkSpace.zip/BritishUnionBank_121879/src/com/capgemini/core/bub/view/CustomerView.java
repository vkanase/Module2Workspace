package com.capgemini.core.bub.view;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.core.bub.bean.Customer;
import com.capgemini.core.bub.exception.CustomerException;
import com.capgemini.core.bub.service.CustomerServiceImpl;
import com.capgemini.core.bub.service.ICustomerService;


public class CustomerView
{
	private ICustomerService customerService ;
	
	public CustomerView() 
	{
		customerService = new CustomerServiceImpl() ;
	}
	
	public static void main(String[] args) 
	{
		CustomerView custview = new CustomerView() ;
		while(true)
		{
			custview.showMenu();
		}
	}
	
	public void showMenu()
	{
		Scanner scanner = new Scanner( System.in ) ;
		
		System.out.println("");
		System.out.println("1. Add Customer ");
		System.out.println("2. Get Customer Information ");
		System.out.println("3. Remove Customer ");
		System.out.println("4. Exit Application ");
		
		System.out.println("Enter Your choice ");
		int choice = scanner.nextInt();
		
		switch(choice)
		{
			case 1 : addCustomer();
				break;
			
			case 2 : getCustomer();
				break;
				
			case 3 : removeCustomer();
				break;
				
			case 4 :System.out.println("Thanks");
					System.exit(0);
				break;
			
			default : System.out.println("Enter Valid Input...");
				break;
		}
	}

	private void addCustomer()
	{
		Scanner scanner = new Scanner( System.in ) ;
		
		System.out.println(" Enter Customer Information ");
		System.out.println("");
		
		System.out.println("Enter Customer Name ");
		String name = scanner.nextLine();
		
		System.out.println("Enter Account Id ");
		int accid = scanner.nextInt() ;
		
		System.out.println("Enter Branch Name ");
		String branchName = scanner.next() ;
		
		System.out.println("Enter age :");
		int age = scanner.nextInt() ;
		
		System.out.println("Enter Occupation ");
		String occup = scanner.next() ;
		
		System.out.println(" Enter Loan Type ");
		System.out.println("Enter Your choice ");
		System.out.println("1. HomeLoan ");
		System.out.println("2. CarLoan ");
		System.out.println("3. PersonalLoan");
		int ch = scanner.nextInt() ;
		String loanType = "";
		switch(ch)
		{
			case 1:
				 loanType = "HomeLoan" ;
				break ;
			case 2:
				 loanType = "CarLoan" ;
				break ;
			case 3:
				loanType = "PersonalLoan" ;
				break ;
			default: 
				System.out.println(" Invalid Input ");
				break ;
		}
		
		
		System.out.println("Enter Loan amount ");
		double amount = scanner.nextDouble() ;
		
		System.out.println("Enter Start Date ");
		String startDate = scanner.next() ;
		
		System.out.println("Enter End Date ");
		String endDate = scanner.next() ;
		
		
		Date stDate = Date.valueOf(startDate);
		Date edDate = Date.valueOf(endDate) ;
		
		Customer cust = new Customer();
		cust.setName(name);
		cust.setAccid(accid);
		cust.setBranchName(branchName);
		cust.setAge(age);
		cust.setOccupation(occup);
		cust.setLoanType(loanType);
		cust.setLoanAmount(amount);
		cust.setStartDate(stDate);
		cust.setEndDate(edDate);
		
		try
		{
			int id = customerService.addCustomer(cust) ;
			System.out.println("Customer Added Successfully with id " + id );
		}
		catch(CustomerException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	private void getCustomer() 
	{
		Scanner scanner = new Scanner( System.in ) ;
		System.out.println(" Retriving Customer Information ");
		System.out.println("");
		System.out.println(" Enter Customer id " );
		int id = scanner.nextInt() ;
		
		try
		{
			Customer customer = customerService.getCustomer(id) ;
			
			System.out.println(" Customer Id " + customer.getCustomerId()) ;
			System.out.println(" Customer Name " + customer.getName() ) ;
			System.out.println(" Account Id " + customer.getAccid() );
			System.out.println(" Branch Name " + customer.getBranchName() );
			System.out.println(" Age " +  customer.getAge() );
			System.out.println(" Occupation " + customer.getOccupation() ) ;
			System.out.println(" Loan Type " + customer.getLoanType() );
			System.out.println(" Loan Amount " + customer.getLoanAmount()); 
			System.out.println(" Start Date " + customer.getStartDate()) ;
			System.out.println(" End Date "  + customer.getEndDate()) ;
			
			double total = customerService.calculateTotal(customer);
		}
		catch( CustomerException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	private void removeCustomer() 
	{
		Scanner scanner = new Scanner(System.in) ;
		System.out.println("");
		System.out.println("Enter Customer id ");
		
		int id = scanner.nextInt() ;
		
		try
		{
			Customer customer = customerService.removeCustomer(id) ;
			
			System.out.println("Customer Id " + id + " removed" );
			System.out.println(" Customer Id " + customer.getCustomerId()) ;
			System.out.println(" Customer Name " + customer.getName() ) ;
			System.out.println(" Account Id " + customer.getAccid() );
			System.out.println(" Branch Name " + customer.getBranchName() );
			System.out.println(" Age " +  customer.getAge() );
			System.out.println(" Occupation " + customer.getOccupation() ) ;
			System.out.println(" Loan Type " + customer.getLoanType() );
			System.out.println(" Loan Amount " + customer.getLoanAmount()); 
			System.out.println(" Start Date " + customer.getStartDate()) ;
			System.out.println(" End Date "  + customer.getEndDate()) ;
		}
		catch(CustomerException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}

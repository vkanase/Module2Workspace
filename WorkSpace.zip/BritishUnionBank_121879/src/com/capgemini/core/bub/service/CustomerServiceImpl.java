package com.capgemini.core.bub.service;

import com.capgemini.core.bub.bean.Customer;
import com.capgemini.core.bub.dao.CustomerDAOImpl;
import com.capgemini.core.bub.dao.ICustomerDAO;
import com.capgemini.core.bub.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService 
{

	private ICustomerDAO customerDAO ;
	public CustomerServiceImpl() 
	{
		customerDAO = new CustomerDAOImpl(); 
	}
	@Override
	public int addCustomer(Customer customer) throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(int id) throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.getCustomer(id);
	}

	@Override
	public Customer removeCustomer(int id) throws CustomerException {
		// TODO Auto-generated method stub
		return customerDAO.removeCustomer(id);
	}
	@Override
	public double calculateTotal(Customer customer) throws CustomerException 
	{
		// TODO Auto-generated method stub
		return customerDAO.calculateTotal(customer);
	}

}

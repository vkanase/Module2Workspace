create table customerBank
(
 	customerid number ,
 	name varchar2(30) ,
 	accountid number ,
 	branchName varchar2(30) ,
 	age number(2) ,
 	occupation varchar2(30) ,
 	loantype varchar2(30),
 	loanamount number(10,2) ,
 	startDate Date ,
 	endDate Date ,
 	primary key (customerid)
);

select * from customerBank ;

create sequence seqCustId start with 10000 ;

select seqCustId.nextval from dual ;

create table loanType 
(
	loantype varchar2(30),
	rateOfInterest number(30)
);

select * from loanType ;


insert into loanType values ('Personal' , 14);
